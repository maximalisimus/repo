# PortProton's PKGBUID 
 PKGBUILD script for installing PortProton on arch-based distros. <img src="portproton.png" width="40"/>


**Usage**:```cd /tmp && git clone https://github.com/Castro-Fidel/PortProton_PKGBUILD && cd PortProton_PKGBUILD && makepkg -si && cd```
