# touchpad_config

This is a PKGBUILD for Arch Linux.
It installs [touchpad_config](https://gitlab.com/Bettehem/touchpad_config) on to your system.

### How to use:
clone this repo:  ```git clone https://gitlab.com/Bettehem/touchpad_config-git.git```  
change directory to repo: ```cd touchpad_config-git```  
make package and install: ```makepkg -si```  
